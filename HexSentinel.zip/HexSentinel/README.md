# 🛡 HexSentinel

HexSentinel is a web-based cybersecurity tool that detects and analyzes potentially harmful files using file signature inspection, entropy calculation, hash generation, and threat scoring.

---

## 🚀 Features

- 🔍 File signature (magic number) detection  
- 🧠 Entropy-based suspicious file detection  
- 🔐 SHA256 hash generation  
- ⚠ Extension mismatch detection  
- 📊 Threat score calculation (0–100%)  
- 🏷 Risk level classification (Low / Medium / High)  
- 🎨 Modern interactive UI  

---

## 🧰 Tech Stack

- Python (Flask)
- HTML5 / CSS3
- python-magic
- Gunicorn (for deployment)

---

## 📂 Project Structure

## 📂 Project Structure
HexSentinel/
│
├── app.py # Main Flask application
├── scanner.py # File analysis logic
├── requirements.txt # Python dependencies

├── static/ # Static assets
│ ├── style.css
│ ├── logo.png
│ └── favicon.png


├── templates/ # HTML templates
│ └── index.html
│
└── uploads/ # Temporary uploaded files


## ⚙ Installation (Local Setup)

### Clone the repository

git clone https://github.com/prajwalkunjekar/HexSentinel.git  
cd HexSentinel  

### Install dependencies

pip install -r requirements.txt  

### Run the application

python app.py  

Open in browser:  
http://127.0.0.1:5000  

---

## 🌍 Deployment

For production deployment:

gunicorn app:app  

Platforms supported:
- Render
- Railway
- Fly.io
- PythonAnywhere

---

## 🛡 How It Works

HexSentinel analyzes uploaded files by:

1. Inspecting file signature (magic number)
2. Checking extension mismatch
3. Calculating entropy
4. Generating SHA256 hash
5. Assigning a threat score and risk level

---

## 👨‍💻 Author

Prajwal Kunjekar  

## 📜 License

This project is for educational and cybersecurity research purposes.
