import os
import magic
import hashlib
import math

def calculate_entropy(file_path):
    with open(file_path, "rb") as f:
        data = f.read()

    if not data:
        return 0

    entropy = 0
    for x in range(256):
        p_x = float(data.count(bytes([x]))) / len(data)
        if p_x > 0:
            entropy += - p_x * math.log2(p_x)

    return round(entropy, 2)

def get_sha256(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            sha256.update(chunk)
    return sha256.hexdigest()

def scan_file(file_path):
    mime_type = magic.from_file(file_path, mime=True)
    extension = os.path.splitext(file_path)[1].lower()
    file_size = round(os.path.getsize(file_path) / 1024, 2)

    threat_score = 0
    suspicious = False

    # Extension mismatch detection
    if extension:
        if "image" in mime_type and extension not in [".jpg", ".jpeg", ".png"]:
            threat_score += 40
            suspicious = True

        if "application/x-dosexec" in mime_type:
            threat_score += 50
            if extension != ".exe":
                threat_score += 20
                suspicious = True

    # Entropy check
    entropy = calculate_entropy(file_path)
    if entropy > 7.5:
        threat_score += 30
        suspicious = True

    if threat_score > 100:
        threat_score = 100

    if threat_score >= 70:
        risk_level = "High"
    elif threat_score >= 40:
        risk_level = "Medium"
    else:
        risk_level = "Low"

    return {
        "filename": os.path.basename(file_path),
        "extension": extension,
        "mime_type": mime_type,
        "sha256": get_sha256(file_path),
        "entropy": entropy,
        "file_size": file_size,
        "threat_score": threat_score,
        "risk_level": risk_level,
        "suspicious": suspicious
    }